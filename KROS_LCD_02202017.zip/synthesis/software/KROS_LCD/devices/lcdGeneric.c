/******************************************************************************
 * NAME:         lcdGeneric.c
 *
 * DESCRIPTION:
 *
 * NOTES:
 *
 *
 * REFERENCES:
 *   None.
 *
 * HISTORY:
 *   2014/9/10:  Initial version
 ******************************************************************************/

/******************************************************************************
 * INCLUDE FILES
 ******************************************************************************/

#include "altera_avalon_lcd_16207_regs.h"
#include "altera_avalon_lcd_16207.h"
#include "lcdGeneric.h"


/******************************************************************************
 * FUNCTION:     mcp23017Backlight
 *
 * DESCRIPTION:  Initialize the default.
 *
 * INPUTS:
 *   None.
 *
 * RETURNS:
 *   None.
 *
 * NOTES:
 *   None.
 ******************************************************************************/
void lcd_backlight (alt_u8 color)
{
	alt_u8 	data = 0;


	data &= 0xFE;
	data |= (~(color >> 2) & 1);
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, data);
}


/******************************************************************************
 * FUNCTION:     lcd_writeMsg
 *
 * DESCRIPTION:
 *
 * INPUTS:
 *   None.
 *
 * RETURNS:
 *   None.
 *
 * NOTES:
 *   None.
 ******************************************************************************/
void lcd_writeMsg(char *msg, int size)
{
	int i;


	for (i = 0; i < size; i++)
	{
		IOWR_ALTERA_AVALON_LCD_16207_DATA(LCD_BASE, *msg);
		msg++;
		usleep(3500);
	}
}


/******************************************************************************
 * FUNCTION:     lcd_writeMsg
 *
 * DESCRIPTION:
 *
 * INPUTS:
 *   None.
 *
 * RETURNS:
 *   None.
 *
 * NOTES:
 *   None.
 ******************************************************************************/
void lcd_init (void)
{
	/* Set function code four times -- 8-bit, 2 line, 5x7 mode */
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x38);
	usleep(4100); /* Wait for more than 4.1 ms */

	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x38);
	usleep(100); /* Wait for more than 100 us */

	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x38);
	usleep(5000); /* Wait for more than 100 us */

	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x38);
	usleep(100); /* Wait for more than 100 us */

	/* Set Display to OFF*/
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x08);
	usleep(2100);

	/* Set Display to ON */
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x0C);
	usleep(2100);

	/* Set Entry Mode -- Cursor increment, display doesn't shift */
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x06);
	usleep(2100);

	/* Set the Cursor to the home position */
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x02);
	usleep(2000);

	/* Display clear */
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x01);
	usleep(2000);

	//lcd_backlight(LCD_WHITE);
}
