
/*
 * This program prints "Hello World" and an array of 1s and 0s indicating the status of a switch to an LCD using the Optrex 16207 KCD Controller Core
 * More information on the core can be found in Chapter 9 of:
 * https://www.altera.com/en_US/pdfs/literature/ug/ug_embedded_ip.pdf
 *
 * "lcdGeneric" is a collection of useful LCD functions developed by Dallas Logic
 * To use this library, define lcdGeneric.h as shown below and manually import
 * lcdGeneric.h and lcdGeneric.c to your workspace
 *
 */

#include <sys/alt_stdio.h>
#include <io.h>
#include <sys/alt_irq.h>
#include "system.h"
#include <unistd.h>

#include "altera_avalon_pio_regs.h"
#include <stdio.h>
#include <stdlib.h>

// Necessary to use LCD IP from Qsys
#include "altera_avalon_lcd_16207_regs.h"
#include "altera_avalon_lcd_16207.h"

#include "devices/lcdGeneric.h"

// Pre-defined delays in microseconds
#define LCD_CMD_DELAY		1000
#define LCD_CHAR_DELAY		2000
#define MAX 1000
#define BLANK 0xff
#define LIT 0x10
#define AMPERSAND 0x40
#define DASH 0xb0
#define COLON 0x3a
#define GREATER_THAN 0x3e
#define LEFT_ARROW 0x7f

struct lcd_char_struct{
		int on_value;
		int off_value;
}ptr[11] = {
		     {LIT,BLANK},
             {AMPERSAND,DASH},
		     {LEFT_ARROW,LIT},
		     {GREATER_THAN,LEFT_ARROW},
		     {AMPERSAND,BLANK},
		     {DASH,LIT},
		     {COLON,BLANK},
		     {GREATER_THAN,'A'},
		     {LEFT_ARROW,BLANK},
		     {BLANK,LIT},
		     {'X','O'}
};

int main(int argc, char* argv[], char* envp[])
{

	int led_value;
	int led_value_updated;

	int i;
	int j;
	int k;
	int pattern_counter = 0;
	int dip_switch_value;
//	int key_value_delayed_read;
//	int key_read_one;


	alt_putstr("Welcome to Knight Rider on Steroids!!\n");

	// Initialize drivers
	lcd_init();

	// Clear display using commands defined in lcdGeneric.h
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, LCD_CLEARDISPLAY);
	usleep(LCD_CMD_DELAY);

	// Set cursor to write on first line
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0x00);
	usleep(LCD_CMD_DELAY);
	lcd_writeMsg("Knight Rider On", 15);
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0xc0); //2nd line
	lcd_writeMsg(" Steroids!", 10);
	usleep(2000000);
	lcd_writeMsg("                ", 16);
	usleep(2000000);
	k=0;

while(1){
	// Set cursor to write on second line
	IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0xc0);
	usleep(LCD_CMD_DELAY);
	led_value  = IORD_ALTERA_AVALON_PIO_DATA(LED_BASE);
	dip_switch_value  = IORD_ALTERA_AVALON_PIO_DATA(DIP_SWITCH_BASE) & 0x3FF;
 //   printf ("dip_switch_value is %d\n", dip_switch_value);
	if (dip_switch_value >= (512)) {pattern_counter = 10;}
	else if (dip_switch_value >= (256)) {pattern_counter = 9;}
	else if (dip_switch_value >= (128)) {pattern_counter = 8;}
	else if (dip_switch_value >= (64)) {pattern_counter = 7;}
	else if (dip_switch_value >= (32)) {pattern_counter = 6;}
	else if (dip_switch_value >= (16)) {pattern_counter = 5;}
	else if (dip_switch_value >= (8)) {pattern_counter = 4;}
	else if (dip_switch_value >= (4)) {pattern_counter = 3;}
	else if (dip_switch_value >= (2)) {pattern_counter = 2;}
	else if (dip_switch_value >= (1)) {pattern_counter = 1;}
	else {pattern_counter = 0;}
	usleep(50000);
    for (i = 0; i <18; i++){
    	led_value_updated  = IORD_ALTERA_AVALON_PIO_DATA(LED_BASE);
    	dip_switch_value  = IORD_ALTERA_AVALON_PIO_DATA(DIP_SWITCH_BASE) & 0x3FF;
      	char binaryString [10] = "0000000000";
      	if (led_value != led_value_updated){
    	    for (j = 9; j >= 0; j--) {
		        k = led_value_updated >> j;
		       if (k&1)
		          binaryString[j] = ptr[pattern_counter].on_value;
		       else
	              binaryString[j] = ptr[pattern_counter].off_value;
    	    }
    	    IOWR_ALTERA_AVALON_LCD_16207_COMMAND(LCD_BASE, 0xc0); // second line
    	    lcd_writeMsg(binaryString, 10);  // displays array of 1s and 0s, 1 indicating the switch is on, 0 indicating the switch is off    }
   	    }
    }
 	led_value  = IORD_ALTERA_AVALON_PIO_DATA(LED_BASE);
}
	return 0;
}
